"""Run actual RTL simulations; report no inferred SRAM power or area."""
import argparse, hashlib, json, os, pathlib, shutil, subprocess
ROOT=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--iverilog');p.add_argument('--vvp');p.add_argument('--ivl-base')
p.add_argument('--log-t',type=int,nargs='+',default=[6,12])
p.add_argument('--vcd',action='store_true')
p.add_argument('--power-wave',type=int,choices=[0,1,2],help='Single DUT window: 0 baseline, 1 gated, 2 SRAM functional only')
p.add_argument('--case',type=int,choices=range(4),default=3)
a=p.parse_args()
portable=ROOT/'tools/iverilog/bin'
iv=a.iverilog or shutil.which('iverilog') or str(portable/'iverilog.exe')
vv=a.vvp or shutil.which('vvp') or str(portable/'vvp.exe')
using_portable=pathlib.Path(iv).resolve()==(portable/'iverilog.exe').resolve()
base=a.ivl_base or (str(ROOT/'tools/iverilog/lib/ivl') if using_portable else None)
rtl=sorted((ROOT/'rtl').glob('*.sv'))
ref=ROOT/'reference'
reference=[ref/n for n in ['sc_grouped_or_top.sv','sc_grouped_or_core.sv','sc_go_cached_accumulator.sv','sc_go_reset_mask.sv']]
out=ROOT/'results';out.mkdir(exist_ok=True)
records=[]
def run(top,sources,tag,params=None,vcd=False,plusargs=None):
    binary=out/(tag+'.vvp')
    cmd=[iv]+(['-B',base] if base else [])+['-g2012','-s',top]
    for key,val in (params or {}).items():cmd+=['-P',f'{top}.{key}={val}']
    cmd+=['-o',str(binary)]+[str(x) for x in sources]
    result=subprocess.run(cmd,capture_output=True,text=True,cwd=ROOT)
    (out/(tag+'_compile.log')).write_text(result.stdout+result.stderr)
    if result.returncode:raise RuntimeError(result.stdout+result.stderr)
    # Old Windows vvp crashes for some absolute VPI/image paths. Use paths
    # relative to cwd, which also avoids leaking host paths into command lines.
    cmd=[vv]+(['-M',os.path.relpath(base,ROOT)] if base else [])+[os.path.relpath(binary,ROOT)]
    if vcd:cmd+=['+VCD='+str(out/(tag+'.vcd'))]
    cmd += plusargs or []
    result=subprocess.run(cmd,capture_output=True,text=True,cwd=ROOT)
    (out/(tag+'.log')).write_text(result.stdout+result.stderr)
    print(result.stdout,end='',flush=True)
    if result.returncode or 'ALL_PASS' not in result.stdout:raise RuntimeError(tag+f' failed returncode={result.returncode}\n'+result.stdout+result.stderr)
    records.append({'test':tag,'passed':True,'log':tag+'.log','frames':result.stdout.count('PASS frame=')})
if a.power_wave is not None:
    tag=f'power_mode{a.power_wave}_case{a.case}'
    run('tb_weight_power',rtl+reference+[ROOT/'sim/tb_weight_power.sv'],tag,
        {'STORAGE':a.power_wave,'LOG_T':12,'OR_GROUP':4,'BATCH':1},True,
        [f'+CASE={a.case}','+POWER_RUN'])
    shutil.move(str(ROOT/'window.json'),str(out/(tag+'_window.json')))
else:
    run('tb_icg',[ROOT/'rtl/sc_ws_icg.sv',ROOT/'sim/tb_icg.sv'],'icg')
    for log_t in a.log_t:
        run('tb_storage_compare',rtl+reference+[ROOT/'sim/tb_storage_compare.sv'],f'compare_t{log_t}',{'LOG_T':log_t},a.vcd)
summary={'status':'PASS_RTL_FUNCTION_AND_CLOCK_ACTIVITY_ONLY','tests':records,
         'sram_ppa_measured':False,'gated_dff_ppa_measured':False,
         'files':{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in rtl}}
summary_path=out/('validation_power_mode'+str(a.power_wave)+'.json' if a.power_wave is not None else 'validation.json')
summary_path.write_text(json.dumps(summary,indent=2)+'\n')
print('Saved '+str(summary_path.relative_to(ROOT))+'; no technology power results claimed')
