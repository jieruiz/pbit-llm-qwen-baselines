"""Count activity inside the measured window. Activity is NOT power."""
import argparse,json,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--mode',type=int,choices=[0,1,2],required=True);p.add_argument('--case',type=int,default=3);a=p.parse_args()
tag=f'power_mode{a.mode}_case{a.case}'
window=json.loads((ROOT/'results'/f'{tag}_window.json').read_text())
start=round(window['start_ns']*1000);end=round(window['end_ns']*1000)
wanted={'tb_weight_power.dut.clk':'main_clock','tb_weight_power.dut.weight_clock':'weight_clock',
        'tb_weight_power.dut.weight_words':'weight_words'}
scopes=[];signals={};units='';header=True;time=0;last={};counts={k:0 for k in wanted.values()}
with (ROOT/'results'/f'{tag}.vcd').open() as f:
    for line in f:
        line=line.strip()
        if header:
            if line.startswith('$scope'):scopes.append(line.split()[2])
            elif line.startswith('$upscope'):scopes.pop()
            elif line.startswith('$var'):
                fields=line.split();name='.'.join(scopes+[fields[4]])
                if name in wanted:signals.setdefault(fields[3],[]).append(wanted[name])
            elif line=='1ps':units='1ps'
            elif line.startswith('$enddefinitions'):header=False
            continue
        if line.startswith('#'):time=int(line[1:]);continue
        if not line or line[0]=='$':continue
        if line[0] in '01xXzZ':value,key=line[0].lower(),line[1:]
        elif line[0]=='b':
            value,key=line[1:].split();value=value.lower().lstrip('0') or '0'
        else:continue
        if key not in signals:continue
        prev=last.get(key);last[key]=value
        if start<=time<end:
            for name in signals[key]:
                if name.endswith('clock'):
                    if value=='1' and prev=='0':counts[name]+=1
                elif prev is not None and value!=prev:counts[name]+=1
if units!='1ps':raise RuntimeError('Expected 1ps VCD timescale')
if {name for names in signals.values() for name in names}!=set(wanted.values()):raise RuntimeError('Missing activity signals')
if counts['main_clock']!=window['cycles_per_frame']:raise RuntimeError('Window clock count mismatch')
if counts['weight_words']!=0:raise RuntimeError('Weights changed during sampling')
if a.mode==0 and counts['weight_clock']!=counts['main_clock']:raise RuntimeError('Baseline clock mismatch')
if a.mode==1 and counts['weight_clock']!=0:raise RuntimeError('Gated weights received clock edges')
result={'status':'PASS_ACTIVITY_ONLY','mode':a.mode,'window':window,'counts':counts,
        'power_measured':False,'sram_ppa_available':False}
(ROOT/'results'/f'{tag}_activity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
