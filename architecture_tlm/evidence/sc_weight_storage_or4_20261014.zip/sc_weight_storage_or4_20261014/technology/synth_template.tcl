# DC template. Requires real library bindings; NOT an executed PPA result.
# Run from package root, set STD_DB, TOP_NAME and (for gated) ICG_BINDING.
foreach required {STD_DB TOP_NAME OPERATING_LIBRARY OPERATING_CONDITION} {
    if {![info exists ::env($required)]} {error "Missing env $required"}
}
set allowed {sc_or4_weight_dff_baseline sc_or4_weight_gated_dff sc_or4_weight_sram}
if {[lsearch -exact $allowed $::env(TOP_NAME)]<0} {error "Unsupported top"}
set_app_var target_library [list $::env(STD_DB)]
set_app_var link_library [list * $::env(STD_DB)]
if {$::env(TOP_NAME) eq "sc_or4_weight_sram"} {
    foreach required {SRAM_BINDING SRAM_DB} {
        if {![info exists ::env($required)]} {error "SRAM has no technology binding: missing $required"}
    }
    set_app_var link_library [concat [get_app_var link_library] [list $::env(SRAM_DB)]]
}
file mkdir results/dc WORK
define_design_lib WORK -path WORK
analyze -format sverilog -define SYNTHESIS [glob rtl/*.sv]
if {$::env(TOP_NAME) eq "sc_or4_weight_gated_dff"} {
    if {![info exists ::env(ICG_BINDING)]} {error "Missing real ICG binding"}
    analyze -format sverilog $::env(ICG_BINDING)
}
if {$::env(TOP_NAME) eq "sc_or4_weight_sram"} {
    analyze -format sverilog $::env(SRAM_BINDING)
}
elaborate $::env(TOP_NAME)
if {![link]} {error "Unresolved technology implementation"}
set_operating_conditions -library $::env(OPERATING_LIBRARY) $::env(OPERATING_CONDITION)
create_clock -name clk -period 10 [get_ports clk]
set_clock_transition 0.100 [get_clocks clk]
set_clock_uncertainty 0.100 [get_clocks clk]
set_input_transition 0.100 [remove_from_collection [all_inputs] [get_ports clk]]
set_input_delay 0.100 -clock clk [remove_from_collection [all_inputs] [get_ports {clk rst_n}]]
set_input_delay 0.100 -clock clk [get_ports rst_n]
set_output_delay 0.100 -clock clk [all_outputs]
set_load 0.001 [all_outputs]
# Match and verify the historical SS1.08V125C corner in all variants.
# Do not case-analyze programmable weights or probability inputs to constants.
compile_ultra -no_autoungroup -no_boundary_optimization
redirect results/dc/check_design.rpt {check_design}
redirect results/dc/area.rpt {report_area -hierarchy}
redirect results/dc/timing.rpt {report_timing -max_paths 20}
redirect results/dc/clock_gating.rpt {report_clock_gating}
redirect results/dc/references.rpt {report_reference -hierarchy}
write -format verilog -hierarchy -output results/dc/mapped.v
write_sdc results/dc/mapped.sdc
write_sdf results/dc/mapped.sdf
# Before accepting power: verify the actual ICG/SRAM references, no black boxes,
# gated clock propagation, clock-gating checks and a matched mapped VCD window.
