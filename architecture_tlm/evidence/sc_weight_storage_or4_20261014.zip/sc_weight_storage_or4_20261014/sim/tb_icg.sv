`timescale 1ns/1ps
module tb_icg;
    reg clk=0,en=0,test_en=0;
    always #5 clk=~clk;
    wire gclk;
    sc_ws_icg dut(clk,en,test_en,gclk);
    integer rises=0;
    time last_rise;
    always @(posedge gclk) begin
        if(clk!==1'b1||$time%10!=5) $fatal(1,"extra/runt rising edge");
        last_rise=$time;rises=rises+1;
    end
    always @(negedge gclk) if(rises>0 && $time-last_rise!=5) $fatal(1,"truncated pulse");
    initial begin
        #6;en=1;#2;en=0; // entirely in clk HIGH: must not generate a pulse
        #3;en=1;        // low phase enables next rising edge
        #5;en=0;       // high phase: existing pulse must finish normally
        #5;test_en=1;   // low phase test override
        #5;test_en=0;
        #15;
        if(rises!=2) $fatal(1,"ICG edge count=%0d",rises);
        $display("ALL_PASS icg glitch/pulse test rises=%0d",rises);$finish;
    end
endmodule
