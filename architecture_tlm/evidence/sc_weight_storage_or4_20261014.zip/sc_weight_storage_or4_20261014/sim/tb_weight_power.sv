`timescale 1ns/1ps
// Single DUT for unambiguous power-waveform scope: tb_grouped_or.dut
// Override OR_GROUP/BATCH/LOG_T at elaboration; identical stimulus for all variants.
module tb_weight_power;
    parameter integer OR_GROUP=4,BATCH=1,LOG_T=12,STORAGE=1;
    localparam integer N=64,W=8,P_W=12,T=1<<LOG_T,ACC_W=27;
    reg clk=0;
    always #5 clk=~clk;
    reg rst_n=0,cfg_we=0,start=0,sample_valid=0,cfg_sign=0;
    reg [5:0] cfg_addr=0;
    reg signed [7:0] cfg_weight=0;
    reg [12:0] cfg_probability=0;
    reg [N*P_W-1:0] random_words=0;
    wire busy,done,update_main;
    wire signed [ACC_W-1:0] raw_sum;
`ifdef DUT_MODULE
    // For mapped fixed tops, set LOG_T=12 and matching OR_GROUP/BATCH in TB.
    `DUT_MODULE dut(
`else
    sc_ws_top #(.OR_GROUP(OR_GROUP),.BATCH(BATCH),.LOG_T(LOG_T),.ACC_W(ACC_W),.STORAGE(STORAGE)) dut(
`endif
        .clk(clk),.rst_n(rst_n),.cfg_weight_we(cfg_we),.cfg_input_we(cfg_we),.cfg_addr(cfg_addr),
        .cfg_weight(cfg_weight),.cfg_probability(cfg_probability),.cfg_sign(cfg_sign),
        .start(start),.sample_valid(sample_valid),.random_words(random_words),
        .busy(busy),.done(done),.update_main(update_main),.raw_sum(raw_sum)
    );
    wire ref_busy,ref_done,ref_update;
    wire signed [26:0] ref_sum;
    sc_grouped_or_top #(.OR_GROUP(OR_GROUP),.BATCH(BATCH),.LOG_T(LOG_T),.ACC_W(27)) reference_dut(
        .clk(clk),.rst_n(rst_n),.cfg_we(cfg_we),.cfg_addr(cfg_addr),
        .cfg_weight(cfg_weight),.cfg_probability(cfg_probability),.cfg_sign(cfg_sign),
        .start(start),.sample_valid(sample_valid),.random_words(random_words),
        .busy(ref_busy),.done(ref_done),.update_main(ref_update),.raw_sum(ref_sum));
    always @(posedge clk) begin
        #1;
        if({busy,done,update_main,raw_sum} !== {ref_busy,ref_done,ref_update,ref_sum}
            || ((^{busy,done,update_main,raw_sum})===1'bx))
            $fatal(1,"REFERENCE_MISMATCH time=%0t",$time);
    end
    integer window_file;
    real window_start;
    integer weights[0:N-1],probs[0:N-1],signs[0:N-1];
    reg sampled[0:N-1];
    reg [31:0] rng=32'hac13b907;
    integer frame,i,t,g,j,b,mag,negative,hp,hn,partial,direct;
    integer expected,batch_pending,used,commits,expected_exact,expected_or;
    integer nominal,gap,case_select,case_arg;
    reg want_commit;
    string vcd_path;
    task advance_rng;
      begin rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);end
    endtask
    task check_idle;
      begin
        @(posedge clk); #1;
        if(busy!==0 || done!==0 || raw_sum!==expected)
          $fatal(1,"idle changed state");
        @(negedge clk);
      end
    endtask
    initial begin
      if($value$plusargs("VCD=%s",vcd_path)) begin
        $dumpfile(vcd_path);$dumpvars(0,dut);
      end
      case_select=-1;case_arg=$value$plusargs("CASE=%d",case_select);
      // CASE=0 zero;1 sparse .01;2 .1;3 .5;4 -128 corner;5 +128 corner;
      // 6 all +127 dense OR collision;7 mixed signs/magnitudes/endpoints.
      repeat(3) @(negedge clk);rst_n=1;
      for(frame=0;frame<8;frame=frame+1) begin
        if(case_select<0 || frame==case_select) begin
          rng=32'hac13b907; // matched across all parameter variants and cases
          for(i=0;i<N;i=i+1) begin
            advance_rng();weights[i]=$signed(rng[7:0]);
            advance_rng();signs[i]=rng[0];
            case(frame)
              0:nominal=0;
              1:nominal=41;
              2:nominal=410;
              3:nominal=2048;
              default:nominal=4096;
            endcase
            advance_rng();probs[i]=nominal;
            if(frame>=1 && frame<=3) probs[i]=(nominal*(2048+(rng%4096)))/4096;
            if(probs[i]>4096)probs[i]=4096;
            if(frame==4 || frame==5)begin weights[i]=-128;signs[i]=(frame==5);end
            if(frame==6)begin weights[i]=127;signs[i]=0;end
            if(frame==7)begin probs[i]=(i%3==0)?0:((i%3==1)?4096:2048);end
            cfg_we=1;cfg_addr=i;cfg_weight=weights[i];cfg_probability=probs[i];cfg_sign=signs[i];
            @(negedge clk);
          end
          cfg_we=0;start=1;
          $display("WINDOW_BEGIN case=%0d time_ps=%0t",frame,$time);
          if($test$plusargs("POWER_RUN")) begin
            if(case_select<0 || $test$plusargs("GAPS")) $fatal(1,"Select one case without gaps");
            window_start=$realtime;
            if(vcd_path!="") $dumpall;
          end
          @(negedge clk);start=0;
          if(busy!==1 || done!==0 || raw_sum!==0)$fatal(1,"start failed");
          expected=0;batch_pending=0;used=0;commits=0;expected_exact=0;expected_or=0;
          for(t=0;t<T;t=t+1)begin
            // Optional gaps for control regression; omit GAPS for power runs.
            if($test$plusargs("GAPS") && t%17==5)begin
              sample_valid=0;random_words=~random_words;
              @(posedge clk);#1;
              if(raw_sum!==expected || done!==0 || busy!==1)$fatal(1,"invalid cycle changed state");
              @(negedge clk);
            end
            // In-flight reconfiguration and start must be ignored.
            cfg_we=(!$test$plusargs("POWER_RUN") && t==3);start=(!$test$plusargs("POWER_RUN") && t==4);
            cfg_addr=0;cfg_weight=0;cfg_probability=0;cfg_sign=0;
            for(i=0;i<N;i=i+1)begin
              advance_rng();random_words[i*P_W+:P_W]=rng[11:0];
              sampled[i]=(rng[11:0]<probs[i]);
            end
            partial=0;direct=0;
            for(i=0;i<N;i=i+1)
              if(sampled[i])direct=direct+(signs[i]?-weights[i]:weights[i]);
            // Independent scalar reference: for each sign/plane/group count
            // one event if any eligible lane fires, then weight by 2**b.
            for(b=0;b<W;b=b+1)begin
              for(g=0;g<N;g=g+OR_GROUP)begin
                hp=0;hn=0;
                for(j=0;j<OR_GROUP;j=j+1)begin
                  i=g+j;mag=(weights[i]<0)?-weights[i]:weights[i];
                  negative=(weights[i]<0)^signs[i];
                  if(sampled[i] && ((mag>>b)&1))begin
                    if(negative)hn=1;else hp=1;
                  end
                end
                partial=partial+((hp-hn)*(1<<b));
              end
            end
            if(OR_GROUP==1 && partial!=direct)$fatal(1,"exact path reference mismatch");
            sample_valid=1;
            expected_exact=expected_exact+direct;expected_or=expected_or+partial;
            batch_pending=batch_pending+partial;used=used+1;
            want_commit=(used==BATCH)||(t==T-1);
            #1;if(update_main!==want_commit)$fatal(1,"commit enable mismatch");
            if(want_commit)begin
              expected=expected+batch_pending;batch_pending=0;used=0;commits=commits+1;
            end
            @(posedge clk);#1;
            if(raw_sum!==expected)$fatal(1,"sum case %0d sample %0d got %0d want %0d",frame,t,raw_sum,expected);
            if(done!==(t==T-1) || busy!==(t!=T-1))$fatal(1,"control mismatch");
            @(negedge clk);
          end
          $display("WINDOW_END case=%0d time_ps=%0t",frame,$time);
          if($test$plusargs("POWER_RUN")) begin
            window_file=$fopen("window.json","w");
            if(!window_file)$fatal(1,"Cannot open window.json");
            $fdisplay(window_file,"{\"start_ns\":%.3f,\"end_ns\":%.3f,\"frames\":1,\"samples_per_frame\":%0d,\"cycles_per_frame\":%0d,\"frequency_MHz\":100,\"group\":%0d,\"batch\":%0d,\"case\":%0d}",window_start,$realtime,T,T+1,OR_GROUP,BATCH,frame);
            $fclose(window_file);
          end
          sample_valid=0;cfg_we=0;start=0;
          if(commits!=(T+BATCH-1)/BATCH || expected_or!=expected)$fatal(1,"final count mismatch");
          $display("PASS G=%0d B=%0d case=%0d samples=%0d updates=%0d raw=%0d exact_same_bits=%0d",OR_GROUP,BATCH,frame,T,commits,raw_sum,expected_exact);
          check_idle();check_idle();
        end
      end
      $display("ALL_PASS G=%0d B=%0d LOG_T=%0d",OR_GROUP,BATCH,LOG_T);$finish;
    end
endmodule
