`timescale 1ns/1ps
// Independent scalar OR scoreboard + historical measurement RTL comparison.
module tb_storage_compare;
    parameter integer LOG_T=6;
    localparam integer N=64,W=8,P_W=12,T=1<<LOG_T,AW=15+LOG_T;
    reg clk=0;
    always #5 clk=~clk;
    reg rst_n=0,cfg_weight_we=0,cfg_input_we=0,start=0,sample_valid=0;
    reg [5:0] cfg_addr=0;
    reg signed [7:0] cfg_weight=0;
    reg [12:0] cfg_probability=0;
    reg cfg_sign=0;
    reg [767:0] random_words=0;
    wire [2:0] busy,done,update_main,weight_clock;
    wire signed [AW-1:0] sum[0:2];
    genvar d;
    generate for(d=0;d<3;d=d+1) begin:duts
        sc_ws_top #(.LOG_T(LOG_T),.STORAGE(d),.ACC_W(AW)) dut(
            .clk(clk),.rst_n(rst_n),.cfg_weight_we(cfg_weight_we),.cfg_input_we(cfg_input_we),
            .start(start),.sample_valid(sample_valid),.cfg_addr(cfg_addr),.cfg_weight(cfg_weight),
            .cfg_probability(cfg_probability),.cfg_sign(cfg_sign),.random_words(random_words),
            .busy(busy[d]),.done(done[d]),.update_main(update_main[d]),.raw_sum(sum[d]),.weight_clock(weight_clock[d]));
    end endgenerate
    wire ref_busy,ref_done,ref_update;
    wire signed [AW-1:0] ref_sum;
    sc_grouped_or_top #(.LOG_T(LOG_T),.OR_GROUP(4),.BATCH(1),.ACC_W(AW)) reference_dut(
        .clk(clk),.rst_n(rst_n),.cfg_we(cfg_weight_we||cfg_input_we),.start(start),.sample_valid(sample_valid),
        .cfg_addr(cfg_addr),.cfg_weight(cfg_weight),.cfg_probability(cfg_probability),.cfg_sign(cfg_sign),
        .random_words(random_words),.busy(ref_busy),.done(ref_done),.update_main(ref_update),.raw_sum(ref_sum));
    integer weights[0:N-1],probs[0:N-1],signs[0:N-1];
    integer frame,i,t,g,j,b,mag,negative,hp,hn,partial,expected,edges_base,edges_gated;
    integer total_base_edges=0,total_gated_edges=0;
    reg count_window=0;
    reg [31:0] rng=32'hac13b907;
    string vcd_path;
    task advance_rng;
        begin rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);end
    endtask
    always @(posedge weight_clock[0]) if(count_window) total_base_edges=total_base_edges+1;
    always @(posedge weight_clock[1]) if(count_window) total_gated_edges=total_gated_edges+1;
    always @(posedge clk) begin
        #1;
        if({busy[0],done[0],update_main[0],sum[0]} !== {ref_busy,ref_done,ref_update,ref_sum})
            $fatal(1,"baseline/reference mismatch time=%0t",$time);
        if({busy[1],done[1],update_main[1],sum[1]} !== {busy[0],done[0],update_main[0],sum[0]} ||
           {busy[2],done[2],update_main[2],sum[2]} !== {busy[0],done[0],update_main[0],sum[0]})
            $fatal(1,"storage mismatch time=%0t",$time);
    end
    initial begin
        if($value$plusargs("VCD=%s",vcd_path)) begin $dumpfile(vcd_path);$dumpvars(0,tb_storage_compare);end
        repeat(3) @(negedge clk);
        rst_n=1;
        // Frames: dense mixed, same weights/new inputs, all -128, input negation,
        // all-positive OR collisions, zero, weight-only reload, final reuse.
        for(frame=0;frame<8;frame=frame+1) begin
            for(i=0;i<N;i=i+1) begin
                if(frame==0) begin
                    advance_rng();weights[i]=$signed(rng[7:0]);
                    advance_rng();signs[i]=rng[0];probs[i]=2048;
                end
                if(frame==1) begin signs[i]=i%2;probs[i]=(i%3==0)?0:((i%3==1)?4096:41);end
                if(frame==2) begin weights[i]=-128;signs[i]=0;probs[i]=4096;end
                if(frame==3) begin signs[i]=1;probs[i]=4096;end
                if(frame==4) begin weights[i]=127;signs[i]=0;probs[i]=4096;end
                if(frame==5) begin signs[i]=0;probs[i]=0;end
                if(frame==6) begin advance_rng();weights[i]=$signed(rng[7:0]);end
                if(frame==7) begin signs[i]=(i%2);probs[i]=410;end
                cfg_weight_we=(frame==0||frame==2||frame==4||frame==6);
                cfg_input_we=(frame!=6);
                cfg_addr=i;cfg_weight=weights[i];cfg_probability=probs[i];cfg_sign=signs[i];
                @(negedge clk);
            end
            cfg_weight_we=0;cfg_input_we=0;start=1;sample_valid=0;
            edges_base=total_base_edges;edges_gated=total_gated_edges;count_window=1;
            @(negedge clk);start=0;
            expected=0;
            for(t=0;t<T;t=t+1) begin
                if(t%17==5) begin
                    sample_valid=0;random_words=~random_words;
                    @(posedge clk);#2;
                    if(sum[0]!==expected) $fatal(1,"invalid sample changed result");
                    @(negedge clk);
                end
                // Runtime writes/restarts must be rejected in all three variants.
                cfg_weight_we=(t==3);cfg_input_we=(t==3);start=(t==4);
                cfg_addr=0;cfg_weight=0;cfg_probability=0;cfg_sign=0;
                for(i=0;i<N;i=i+1) begin advance_rng();random_words[i*12+:12]=rng[11:0];end
                partial=0;
                for(b=0;b<W;b=b+1) for(g=0;g<N;g=g+4) begin
                    hp=0;hn=0;
                    for(j=0;j<4;j=j+1) begin
                        i=g+j;mag=weights[i]<0?-weights[i]:weights[i];
                        negative=(weights[i]<0)^signs[i];
                        if(random_words[i*12+:12]<probs[i] && ((mag>>b)&1)) begin
                            if(negative)hn=1;else hp=1;
                        end
                    end
                    partial=partial+((hp-hn)*(1<<b));
                end
                sample_valid=1;expected=expected+partial;
                @(posedge clk);#2;
                if(sum[0]!==expected||sum[1]!==expected||sum[2]!==expected)
                    $fatal(1,"scalar scoreboard frame=%0d t=%0d expected=%0d got=%0d",frame,t,expected,sum[0]);
                if(done[0]!==(t==T-1)||busy[0]!==(t!=T-1)) $fatal(1,"control mismatch");
                @(negedge clk);
            end
            count_window=0;cfg_weight_we=0;cfg_input_we=0;sample_valid=0;start=0;
            if(total_gated_edges!=edges_gated) $fatal(1,"weight clock ran during computation");
            if(total_base_edges-edges_base<T+1) $fatal(1,"baseline clock edge audit failed");
            $display("PASS frame=%0d samples=%0d sum=%0d baseline_weight_edges=%0d gated_weight_edges=%0d",frame,T,expected,total_base_edges-edges_base,total_gated_edges-edges_gated);
            repeat(2) @(negedge clk);
        end
        // Abort a live frame and reset the closed gate + SRAM validity.
        start=1;@(negedge clk);start=0;sample_valid=1;
        repeat(3) @(negedge clk);
        rst_n=0;sample_valid=0;
        repeat(2) @(negedge clk);
        if(sum[0]!==0||sum[1]!==0||sum[2]!==0||busy!==0) $fatal(1,"reset while busy failed");
        rst_n=1;
        // Unwritten SRAM entries must remain masked, not rely on initialization.
        // Enable every input so missing SRAM masking would propagate X values.
        for(i=0;i<N;i=i+1) begin
            cfg_input_we=1;cfg_weight_we=0;cfg_addr=i;
            cfg_probability=4096;cfg_sign=0;cfg_weight=0;
            @(negedge clk);
        end
        cfg_input_we=0;
        start=1;@(negedge clk);start=0;sample_valid=1;
        for(t=0;t<T;t=t+1) begin random_words=0;@(negedge clk);end
        if(sum[0]!==0||sum[1]!==0||sum[2]!==0) $fatal(1,"reset/unwritten memory masking failed");
        sample_valid=0;
        // Reload only two addresses; all remaining SRAM words stay invalid.
        cfg_weight_we=1;cfg_addr=0;cfg_weight=1;@(negedge clk);
        cfg_addr=63;cfg_weight=-128;@(negedge clk);
        cfg_weight_we=0;start=1;@(negedge clk);start=0;sample_valid=1;
        for(t=0;t<T;t=t+1) begin random_words=0;@(negedge clk);end
        if(sum[0]!==(-127*T)||sum[1]!==(-127*T)||sum[2]!==(-127*T)) $fatal(1,"partial SRAM reload failed");
        $display("ALL_PASS storage_compare LOG_T=%0d frames=8 plus reset recovery",LOG_T);
        $finish;
    end
endmodule
