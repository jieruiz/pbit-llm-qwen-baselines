`timescale 1ns/1ps
// Fixed signed weights; ordinary, potentially colliding input bit streams.
// OR_GROUP=1 is exact for the supplied bits. Larger groups lose collisions.
module sc_ws_or_core #(
    parameter integer N=64, W=8, LOG_T=12, OR_GROUP=4, BATCH=4,
    parameter integer ADDR_W=(N>1?$clog2(N):1),
    parameter integer ACC_W=W+$clog2(N)+1+LOG_T
)(
    input wire clk, rst_n, cfg_any, start, sample_valid,
    input wire [N*(W+1)-1:0] weight_words,
    input wire [N-1:0] bits_in, sign_in,
    output wire busy, done, update_main,
    output wire signed [ACC_W-1:0] raw_sum
);
    localparam integer GROUPS=N/OR_GROUP;
    localparam integer COUNT_W=$clog2(GROUPS+1);
    localparam integer PART_W=W+$clog2(GROUPS)+1;
    localparam integer PLANE_PAD=1<<$clog2(W);
    wire [W-1:0] weight_mag[0:N-1];
    wire [N-1:0] weight_sign;
    reg [LOG_T-1:0] sample_index;
    wire begin_frame=start&&!busy&&!cfg_any;
    wire accept=busy&&sample_valid;
    wire last=&sample_index;
    wire [LOG_T-1:0] next_index=begin_frame?{LOG_T{1'b0}}:
        (accept?sample_index+1'b1:sample_index);
    wire [LOG_T-1:0] reset_index;
    sc_ws_reset_mask #(.WIDTH(LOG_T)) u_index_mask(rst_n,next_index,reset_index);
    always @(posedge clk) sample_index<=reset_index;
    genvar wi;
    generate for(wi=0;wi<N;wi=wi+1) begin:weight_decode
        assign weight_mag[wi]=weight_words[wi*(W+1)+:W];
        assign weight_sign[wi]=weight_words[wi*(W+1)+W];
    end endgenerate

    wire [N-1:0] negative=weight_sign^sign_in;
    wire signed [PART_W-1:0] weighted_tree[1:2*PLANE_PAD-1];
    genvar b,g,j,n;
    generate
      for(b=0;b<W;b=b+1) begin:planes
        wire [GROUPS-1:0] pos,neg;
        for(g=0;g<GROUPS;g=g+1) begin:groups
          wire [OR_GROUP-1:0] pterm,nterm;
          for(j=0;j<OR_GROUP;j=j+1) begin:lanes
            localparam integer LANE=g*OR_GROUP+j;
            wire hit=accept&&bits_in[LANE]&&weight_mag[LANE][b];
            assign pterm[j]=hit&&!negative[LANE];
            assign nterm[j]=hit&&negative[LANE];
          end
          assign pos[g]=|pterm;
          assign neg[g]=|nterm;
        end
        wire [COUNT_W-1:0] pos_count,neg_count;
        sc_ws_popcount #(.N(GROUPS)) u_pos(.bits_in(pos),.count(pos_count));
        sc_ws_popcount #(.N(GROUPS)) u_neg(.bits_in(neg),.count(neg_count));
        wire signed [PART_W-1:0] pext={{(PART_W-COUNT_W){1'b0}},pos_count};
        wire signed [PART_W-1:0] nextend={{(PART_W-COUNT_W){1'b0}},neg_count};
        // Extend BEFORE subtraction and shift. Constant shifts are wiring.
        assign weighted_tree[PLANE_PAD+b]=(pext-nextend)<<<b;
      end
      for(b=W;b<PLANE_PAD;b=b+1) begin:padding
        assign weighted_tree[PLANE_PAD+b]=0;
      end
      for(n=1;n<PLANE_PAD;n=n+1) begin:weighted_reduce
        assign weighted_tree[n]=weighted_tree[2*n]+weighted_tree[2*n+1];
      end
    endgenerate
    sc_ws_cached_accumulator #(.IN_W(PART_W),.ACC_W(ACC_W),.BATCH(BATCH)) u_time(
        .clk(clk),.rst_n(rst_n),.start(begin_frame),.valid(sample_valid),
        .last(last),.partial(weighted_tree[1]),.busy(busy),.done(done),
        .total(raw_sum),.update_main(update_main)
    );
    // Supported: power-of-two N and OR_GROUP, N divisible by OR_GROUP;
    // power-of-two BATCH; LOG_T>=1; ACC_W>=PART_W+clog2(BATCH).
    // synthesis translate_off
    initial begin
        if(N<1 || (N&(N-1))!=0 || OR_GROUP<1 || (OR_GROUP&(OR_GROUP-1))!=0 || N%OR_GROUP!=0)
            $fatal(1,"Invalid N / OR_GROUP");
        if(W<2 || LOG_T<1 || BATCH<1 || (BATCH&(BATCH-1))!=0 || ACC_W<PART_W+$clog2(BATCH))
            $fatal(1,"Invalid width / BATCH");
    end
    // synthesis translate_on
endmodule

// Balanced exact popcount. Each level grows by only one bit.
module sc_ws_popcount #(
    parameter integer N=16,
    parameter integer OUT_W=$clog2(N+1)
)(input wire [N-1:0] bits_in, output wire [OUT_W-1:0] count);
    localparam integer LEVELS=$clog2(N);
    genvar l,k;
    generate
      for(l=0;l<=LEVELS;l=l+1) begin:levels
        wire [l:0] value[0:(N>>l)-1];
        for(k=0;k<(N>>l);k=k+1) begin:nodes
          if(l==0) assign value[k]=bits_in[k];
          else assign value[k]={1'b0,levels[l-1].value[2*k]}+{1'b0,levels[l-1].value[2*k+1]};
        end
      end
    endgenerate
    assign count=levels[LEVELS].value[0];
endmodule
