`timescale 1ns/1ps
module sc_ws_top #(
    parameter integer N=64,W=8,P_W=12,LOG_T=12,OR_GROUP=4,BATCH=1,STORAGE=1,
    parameter integer ADDR_W=$clog2(N),ACC_W=W+$clog2(N)+1+LOG_T
)(input wire clk,rst_n,cfg_weight_we,cfg_input_we,start,sample_valid,
  input wire [ADDR_W-1:0] cfg_addr,input wire signed [W-1:0] cfg_weight,
  input wire [P_W:0] cfg_probability,input wire cfg_sign,
  input wire [N*P_W-1:0] random_words,
  output wire busy,done,update_main,output wire signed [ACC_W-1:0] raw_sum,
  output wire weight_clock);
    reg [P_W:0] probability[0:N-1];
    reg [N-1:0] input_sign;
    wire [N-1:0] bits_in;
    wire [N*(W+1)-1:0] weight_words;
    // Preserve the historical probability/sign DFF+reset-mask implementation.
    genvar i;
    generate for(i=0;i<N;i=i+1) begin:probability_reset
        wire [P_W+1:0] next_config=(cfg_input_we&&!busy&&cfg_addr==i)?
            {cfg_probability,cfg_sign}:{probability[i],input_sign[i]};
        wire [P_W+1:0] reset_config;
        sc_ws_reset_mask #(.WIDTH(P_W+2)) u_mask(rst_n,next_config,reset_config);
        always @(posedge clk) {probability[i],input_sign[i]}<=reset_config;
        assign bits_in[i]=({1'b0,random_words[i*P_W+:P_W]}<probability[i]);
    end endgenerate
    sc_ws_weight_store #(.N(N),.W(W),.MODE(STORAGE),.ADDR_W(ADDR_W)) u_weights(
        .clk(clk),.rst_n(rst_n),.we(cfg_weight_we&&!busy),.addr(cfg_addr),
        .weight(cfg_weight),.words(weight_words),.weight_clock(weight_clock));
    sc_ws_or_core #(.N(N),.W(W),.LOG_T(LOG_T),.OR_GROUP(OR_GROUP),.BATCH(BATCH),.ACC_W(ACC_W)) u_core(
        .clk(clk),.rst_n(rst_n),.cfg_any(cfg_input_we||cfg_weight_we),
        .start(start),.sample_valid(sample_valid),.weight_words(weight_words),
        .bits_in(bits_in),.sign_in(input_sign),.busy(busy),.done(done),
        .update_main(update_main),.raw_sum(raw_sum));
endmodule
