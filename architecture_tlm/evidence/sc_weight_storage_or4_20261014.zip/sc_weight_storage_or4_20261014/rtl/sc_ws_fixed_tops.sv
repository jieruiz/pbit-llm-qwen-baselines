`timescale 1ns/1ps
// N64 W8 P12 T4096 OR4 B1. Compile ONE top for PPA.

module sc_or4_weight_dff_baseline(
    input wire clk,rst_n,cfg_weight_we,cfg_input_we,start,sample_valid,
    input wire [5:0] cfg_addr,input wire signed [7:0] cfg_weight,
    input wire [12:0] cfg_probability,input wire cfg_sign,
    input wire [767:0] random_words,output wire busy,done,update_main,
    output wire signed [26:0] raw_sum,output wire weight_clock
);
    sc_ws_top #(.STORAGE(0)) u_dut(
 .clk(clk),.rst_n(rst_n),.cfg_weight_we(cfg_weight_we),.cfg_input_we(cfg_input_we),
        .start(start),.sample_valid(sample_valid),.cfg_addr(cfg_addr),.cfg_weight(cfg_weight),
        .cfg_probability(cfg_probability),.cfg_sign(cfg_sign),.random_words(random_words),
        .busy(busy),.done(done),.update_main(update_main),.raw_sum(raw_sum),.weight_clock(weight_clock)
    );
endmodule

module sc_or4_weight_gated_dff(
    input wire clk,rst_n,cfg_weight_we,cfg_input_we,start,sample_valid,
    input wire [5:0] cfg_addr,input wire signed [7:0] cfg_weight,
    input wire [12:0] cfg_probability,input wire cfg_sign,
    input wire [767:0] random_words,output wire busy,done,update_main,
    output wire signed [26:0] raw_sum,output wire weight_clock
);
    sc_ws_top #(.STORAGE(1)) u_dut(
 .clk(clk),.rst_n(rst_n),.cfg_weight_we(cfg_weight_we),.cfg_input_we(cfg_input_we),
        .start(start),.sample_valid(sample_valid),.cfg_addr(cfg_addr),.cfg_weight(cfg_weight),
        .cfg_probability(cfg_probability),.cfg_sign(cfg_sign),.random_words(random_words),
        .busy(busy),.done(done),.update_main(update_main),.raw_sum(raw_sum),.weight_clock(weight_clock)
    );
endmodule

module sc_or4_weight_sram(
    input wire clk,rst_n,cfg_weight_we,cfg_input_we,start,sample_valid,
    input wire [5:0] cfg_addr,input wire signed [7:0] cfg_weight,
    input wire [12:0] cfg_probability,input wire cfg_sign,
    input wire [767:0] random_words,output wire busy,done,update_main,
    output wire signed [26:0] raw_sum,output wire weight_clock
);
    sc_ws_top #(.STORAGE(2)) u_dut(
 .clk(clk),.rst_n(rst_n),.cfg_weight_we(cfg_weight_we),.cfg_input_we(cfg_input_we),
        .start(start),.sample_valid(sample_valid),.cfg_addr(cfg_addr),.cfg_weight(cfg_weight),
        .cfg_probability(cfg_probability),.cfg_sign(cfg_sign),.random_words(random_words),
        .busy(busy),.done(done),.update_main(update_main),.raw_sum(raw_sum),.weight_clock(weight_clock)
    );
endmodule
