`timescale 1ns/1ps
// Signed temporal accumulator comparison. Same stream, same exact final sum.
// start is a separate cycle; accept data only while busy. last marks final valid.
// BATCH=1 is the every-cycle baseline; BATCH=4/8 cache short partial results.
// No manual gated clocks: enables are explicit. Library ICG must be requested
// and checked in synthesis before claiming any clock-tree energy reduction.
module sc_ws_cached_accumulator #(
    parameter integer IN_W=15,
    parameter integer ACC_W=27,
    parameter integer BATCH=4,
    parameter integer COUNT_W=(BATCH>1?$clog2(BATCH):1),
    parameter integer SUM_W=IN_W+$clog2(BATCH)
)(
    input wire clk,rst_n,start,valid,last,
    input wire signed [IN_W-1:0] partial,
    output reg busy,done,
    output reg signed [ACC_W-1:0] total,
    output wire update_main
);
    reg [COUNT_W-1:0] used;
    localparam integer STORED=(BATCH>1?BATCH-1:1);
    reg signed [IN_W-1:0] cache[0:STORED-1];
    wire accept=busy&&valid&&!start;
    assign update_main=accept&&((used==BATCH-1)||last);
    // BATCH must be a power of two. Isolate the batch reduction and main adder
    // while caching. Signed extension prevents errors for negative partials.
    wire signed [SUM_W-1:0] tree[1:2*BATCH-1];
    genvar i;
    generate
      for(i=0;i<BATCH;i=i+1) begin:leaf
        wire signed [IN_W-1:0] value;
        if(i<BATCH-1) begin:cached
          assign value=(i<used)?cache[i]:((i==used)?partial:{IN_W{1'b0}});
        end else begin:current
          assign value=(i==used)?partial:{IN_W{1'b0}};
        end
        assign tree[BATCH+i]=update_main?{{(SUM_W-IN_W){value[IN_W-1]}},value}:{SUM_W{1'b0}};
      end
      for(i=1;i<BATCH;i=i+1) begin:reduce
        assign tree[i]=tree[2*i]+tree[2*i+1];
      end
    endgenerate
    wire signed [ACC_W-1:0] main_operand=update_main?total:{ACC_W{1'b0}};
    wire signed [ACC_W-1:0] extended_sum={{(ACC_W-SUM_W){tree[1][SUM_W-1]}},tree[1]};
    wire signed [ACC_W-1:0] next_total=main_operand+extended_sum;
    reg next_busy,next_done;
    reg [COUNT_W-1:0] next_used;
    reg [ACC_W-1:0] next_acc;
    wire [ACC_W+COUNT_W+1:0] reset_state;
    always @* begin
        next_busy=busy;next_done=0;next_used=used;next_acc=total;
        if(start&&!busy) begin next_busy=1;next_acc=0;next_used=0;end
        else if(accept) begin
            if(update_main) begin next_acc=next_total;next_used=0;end
            else next_used=used+1'b1;
            if(last) begin next_busy=0;next_done=1;end
        end
    end
    sc_ws_reset_mask #(.WIDTH(ACC_W+COUNT_W+2)) u_state_mask(
        rst_n,{next_busy,next_done,next_used,next_acc},reset_state);
    always @(posedge clk) {busy,done,used,total}<=reset_state;
    genvar ci;
    generate if(BATCH>1) begin:cache_storage
      for(ci=0;ci<STORED;ci=ci+1) begin:entry
        wire [IN_W-1:0] next_cache=(accept&&!update_main&&used==ci)?partial:cache[ci];
        wire [IN_W-1:0] reset_cache;
        sc_ws_reset_mask #(.WIDTH(IN_W)) u_mask(rst_n,next_cache,reset_cache);
        always @(posedge clk) cache[ci]<=reset_cache;
      end
    end endgenerate
endmodule
