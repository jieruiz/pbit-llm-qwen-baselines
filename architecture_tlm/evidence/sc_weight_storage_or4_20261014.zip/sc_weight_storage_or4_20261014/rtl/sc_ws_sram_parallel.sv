`timescale 1ns/1ps
// FUNCTIONAL ONLY: one addressed write, ALL N words continuously visible.
// Not equivalent to a conventional N-deep, one-word-output SRAM macro.
// No reset/initial zeroing of the memory; top-level valid bits mask unwritten data.
module sc_ws_sram_parallel #(
    parameter integer N=64,WORD_W=9,ADDR_W=$clog2(N)
)(input wire clk,we,input wire [ADDR_W-1:0] waddr,
  input wire [WORD_W-1:0] wdata,output wire [N*WORD_W-1:0] q);
`ifdef SYNTHESIS
    // Intentionally unresolved until a real parallel-read/banked implementation
    // and its .lib/.db, timing, power and simulation models have been supplied.
    sc_ws_tech_sram_parallel #(.N(N),.WORD_W(WORD_W),.ADDR_W(ADDR_W)) u_macro(
        .clk(clk),.we(we),.waddr(waddr),.wdata(wdata),.q(q));
`else
    reg [WORD_W-1:0] mem[0:N-1];
    always @(posedge clk) if(we && waddr<N) mem[waddr]<=wdata;
    genvar i;
    generate for(i=0;i<N;i=i+1) begin:read_words
        assign q[i*WORD_W+:WORD_W]=mem[i];
    end endgenerate
`endif
endmodule
