`timescale 1ns/1ps
// Simulation model: capture enable only while clk is LOW (no raw clk & enable).
// For technology synthesis provide sc_ws_tech_icg with clk/en/test_en/gclk ports.
module sc_ws_icg(input wire clk,en,test_en,output wire gclk);
`ifdef SYNTHESIS
    sc_ws_tech_icg u_cell(.clk(clk),.en(en),.test_en(test_en),.gclk(gclk));
`else
    reg enable_latched;
    always @* if(!clk) enable_latched=en|test_en;
    assign gclk=clk&enable_latched;
`endif
endmodule
