`timescale 1ns/1ps
// MODE: 0 baseline DFF, 1 true gated-clock DFF, 2 functional parallel SRAM.
// Same W+1 sign/magnitude format as historical OR4 measurement (N64 => 576 bits).
module sc_ws_weight_store #(
    parameter integer N=64,W=8,MODE=1,ADDR_W=$clog2(N)
)(input wire clk,rst_n,we,input wire [ADDR_W-1:0] addr,
  input wire signed [W-1:0] weight,output wire [N*(W+1)-1:0] words,
  output wire weight_clock);
    wire [W-1:0] magnitude=weight[W-1]?(~weight+1'b1):weight;
    wire [W:0] data={weight[W-1],magnitude};
    genvar i;
    generate if(MODE==2) begin:sram_store
        wire [N*(W+1)-1:0] raw_words;
        reg [N-1:0] valid_words;
        // Validity, not SRAM contents, is synchronously reset.
        always @(posedge clk)
            if(!rst_n) valid_words<=0;
            else if(we && addr<N) valid_words[addr]<=1'b1;
        sc_ws_sram_parallel #(.N(N),.WORD_W(W+1),.ADDR_W(ADDR_W)) u_sram(
            .clk(clk),.we(we&&rst_n),.waddr(addr),.wdata(data),.q(raw_words));
        for(i=0;i<N;i=i+1) begin:mask_unwritten
            assign words[i*(W+1)+:(W+1)]=valid_words[i]?raw_words[i*(W+1)+:(W+1)]:{(W+1){1'b0}};
        end
        // SRAM write/read behavior is not represented by a DFF clock signal.
        assign weight_clock=1'b0;
    end else begin:dff_store
        wire storage_clk;
        if(MODE==1) begin:clock_gate
            // Reset must open the gate so synchronous reset reaches the weights.
            sc_ws_icg u_icg(.clk(clk),.en(!rst_n||we),.test_en(1'b0),.gclk(storage_clk));
        end else begin:ungated
            assign storage_clk=clk;
        end
        assign weight_clock=storage_clk;
        for(i=0;i<N;i=i+1) begin:word
            reg [W:0] state;
            wire [W:0] next_word=(we&&addr==i)?data:state;
            wire [W:0] reset_word;
            sc_ws_reset_mask #(.WIDTH(W+1)) u_mask(rst_n,next_word,reset_word);
            always @(posedge storage_clk) state<=reset_word;
            assign words[i*(W+1)+:(W+1)]=state;
        end
    end endgenerate
    // synthesis translate_off
    initial if(MODE<0||MODE>2||N<2) $fatal(1,"Invalid storage parameters");
    // synthesis translate_on
endmodule
