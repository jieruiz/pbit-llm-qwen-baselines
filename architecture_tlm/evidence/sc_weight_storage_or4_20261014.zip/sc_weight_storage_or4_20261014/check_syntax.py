from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'accumulator_cache_20261013/.deps'))
import pyslang
c=pyslang.ast.Compilation()
files=list((ROOT/'rtl').glob('*.sv'))+list((ROOT/'sim').glob('*.sv'))
ref=ROOT/'reference'
files += [ref/n for n in ['sc_grouped_or_top.sv','sc_grouped_or_core.sv','sc_go_cached_accumulator.sv','sc_go_reset_mask.sv']]
for f in files:c.addSyntaxTree(pyslang.syntax.SyntaxTree.fromText(f.read_text(),name=str(f)))
c.getRoot();diags=c.getAllDiagnostics();errors=[d for d in diags if d.isError()]
report=pyslang.DiagnosticEngine.reportAll(c.sourceManager,diags)
(ROOT/'results/syntax_diagnostics.txt').write_text(report)
print(f'Elaboration: {len(errors)} errors, {len(diags)-len(errors)} warnings')
if errors:print(report);raise SystemExit(1)
