`timescale 1ns/1ps
// Preserved synchronous D-path mask. Included in all area/power accounting.
module sc_go_reset_mask #(parameter WIDTH=1)(
    input rst_n,input [WIDTH-1:0] data_i,output [WIDTH-1:0] data_o);
    assign data_o=data_i & {WIDTH{rst_n}};
endmodule
