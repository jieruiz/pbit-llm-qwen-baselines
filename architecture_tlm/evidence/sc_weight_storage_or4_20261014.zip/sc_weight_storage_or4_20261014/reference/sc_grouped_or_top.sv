`timescale 1ns/1ps
// Includes programmable probability/sign storage and ordinary comparators.
// Uniform random words are INPUTS; no RNG or mutual-exclusion remapping here.
module sc_grouped_or_top #(
    parameter integer N=64,W=8,P_W=12,LOG_T=12,OR_GROUP=4,BATCH=4,
    parameter integer ADDR_W=(N>1?$clog2(N):1),
    parameter integer ACC_W=W+$clog2(N)+1+LOG_T
)(
    input wire clk,rst_n,cfg_we,start,sample_valid,
    input wire [ADDR_W-1:0] cfg_addr,
    input wire signed [W-1:0] cfg_weight,
    input wire [P_W:0] cfg_probability,
    input wire cfg_sign,
    input wire [N*P_W-1:0] random_words,
    output wire busy,done,update_main,
    output wire signed [ACC_W-1:0] raw_sum
);
    reg [P_W:0] probability[0:N-1];
    reg [N-1:0] input_sign;
    wire [N-1:0] bits_in;
    genvar pi;
    generate for(pi=0;pi<N;pi=pi+1) begin:probability_reset
        wire [P_W+1:0] next_config=(cfg_we&&!busy&&cfg_addr==pi)?
            {cfg_probability,cfg_sign}:{probability[pi],input_sign[pi]};
        wire [P_W+1:0] reset_config;
        sc_go_reset_mask #(.WIDTH(P_W+2)) u_mask(rst_n,next_config,reset_config);
        always @(posedge clk) {probability[pi],input_sign[pi]}<=reset_config;
    end endgenerate
    genvar i;
    generate for(i=0;i<N;i=i+1) begin:encoders
        // Codes 0..2**P_W encode [0,1], including both endpoints.
        assign bits_in[i]=({1'b0,random_words[i*P_W+:P_W]}<probability[i]);
    end endgenerate
    sc_grouped_or_core #(.N(N),.W(W),.LOG_T(LOG_T),.OR_GROUP(OR_GROUP),
        .BATCH(BATCH),.ACC_W(ACC_W)) u_core(
        .clk(clk),.rst_n(rst_n),.cfg_we(cfg_we),.cfg_addr(cfg_addr),
        .cfg_weight(cfg_weight),.start(start),.sample_valid(sample_valid),
        .bits_in(bits_in),.sign_in(input_sign),.busy(busy),.done(done),
        .update_main(update_main),.raw_sum(raw_sum)
    );
endmodule
