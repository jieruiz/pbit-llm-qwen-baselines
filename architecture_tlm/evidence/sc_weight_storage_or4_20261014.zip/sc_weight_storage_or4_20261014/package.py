"""Pack portable source/reference/logs; exclude simulators, VCD and binaries."""
from pathlib import Path
import json,zipfile,hashlib
ROOT=Path(__file__).resolve().parent
out=ROOT.parent/(ROOT.name+'.zip')
included=[]
files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or any(x in p.relative_to(ROOT).parts for x in ['tools','__pycache__','WORK']):continue
    if p.suffix in ['.vvp','.vcd','.zip'] or p.name=='package_manifest.json':continue
    files.append(p)
    included.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(ROOT/'package_manifest.json').write_text(json.dumps({'archive':out.name,'files':included},indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[ROOT/'package_manifest.json']:
        z.write(p,str(Path(ROOT.name)/p.relative_to(ROOT)))
print(out)
