# OR4并行计数：权重SRAM / 门控DFF对照

2026-10-14。基于已有任务38015538的测量RTL，保留概率/符号寄存器、OR分组、平衡并行计数、位平面加权和与时间累加，替换权重存储。

| 固定顶层 | 权重存储 | 状态 |
|---|---|---|
| sc_or4_weight_gated_dff | 一个真实门控时钟驱动576位DFF | 功能模型可模拟；工艺综合需要ICG绑定 |
| sc_or4_weight_sram | 64个9位词，所有词同时可见 | 无IP时仅功能行为模型；综合需要真实宏/局部保持实现 |
| sc_or4_weight_dff_baseline | 576位未门控DFF | 同口径基准 |

默认N64、INT8权重、12位随机数、13位概率阈值、4096采样、OR_GROUP=4、BATCH=1，输出raw_sum宽度27位。
每个权重位平面、每个符号分别4合1；其余组输出精确popcount。不是DS-CIM互斥重映射，OR碰撞偏差仍然存在。
SRAM和DFF都保存与历史实现一致的9位符号/幅度；没有同时改变权重编码来掩盖存储收益。

## 接口

- cfg_weight_we：空闲时写一项权重，加载完成后可在多个输入帧间复用。
- cfg_input_we：空闲时写对应的概率与输入符号，独立于权重加载。
- cfg_addr：两种加载共享地址；两种使能同时为1时同时配置该地址。
- start：两种配置使能均为0且空闲时启动一帧。
- sample_valid：为1时采样；为0时暂停计数，但概率存储和比较器没有新增门控。
- random_words：外部提供64x12位随机数。本包不包含RNG。
- weight_clock：仅供检查DFF权重时钟；SRAM模式固定为0，不代表SRAM功耗为0。

所有配置控制在主时钟域内。无额外CDC支持。低有效同步复位应至少覆盖一个完整低相位及随后的上升沿，让ICG打开并复位权重。
SRAM不假定上电为0，未写地址由valid位屏蔽。复位后可加载部分权重，其余项贡献0。
现有概率阈值在帧内保持不变，每拍变化的是random_words；本次仍按要求完整保留其原来的未门控实现。

## 实际RTL仿真

```text
python build_sources.py
python check_syntax.py
python run_sim.py --log-t 6 12
python run_sim.py --log-t 6 --vcd
python run_sim.py --power-wave 0 --case 3
python run_sim.py --power-wave 1 --case 3
python run_sim.py --power-wave 2 --case 3
python audit_wave.py --mode 1 --case 3
```

`check_syntax.py` 使用项目已有pyslang，或Python环境中安装的pyslang；`run_sim.py` 使用PATH中的Icarus，或本目录tools中的便携版本。可传 --iverilog、--vvp、--ivl-base 指定环境。
便携Windows工具可能需要直接在普通终端运行；某些沙箱环境会发生旧工具DLL重定位错误。这不是RTL失败。
测试同时对比三方案、历史OR4/B1测量RTL和独立标量逐组逐位参考；包含正负权重、-128、概率0/1、碰撞、新输入复用权重、只写权重、valid空拍、运行中配置屏蔽、复位中止和未写SRAM屏蔽。
`sim/tb_icg.sv` 单独检查高电平期间使能变化不产生额外上升沿、不截断时钟脉冲。
多DUT回归波形仅用于功能，不可把三DUT合计功耗当成某一方案。
`--power-wave`每次只dump一个DUT，输出对应VCD和window.json，默认4097周期无空拍，配置与复位不在功耗窗口内。
模式2波形仍只代表行为SRAM接口，不能据此计算真实SRAM功耗。
`audit_wave.py`检查RTL单DUT测量窗口的主时钟/权重时钟上升沿，以及权重数据是否稳定。它不把活动次数转换为能量。
源码压缩包排除工具二进制、`.vvp`和较大的`.vcd`；本地波形仍在results保留，解压后运行上面的命令可重新生成。

## 工艺仿真

先看 `technology/README_ZH.md`。普通`reg mem`综合成DFF的结果不能命名为SRAM能耗；缺少IP时不能补写0能耗。
正式流程每次综合一个固定顶层；使用`SYNTHESIS`并提供真实绑定/库。门级仿真重新核对功能、VCD标注和门控检查。
先比较baseline/gated的实际映射能量，再在SRAM模型具备功耗/时序/面积后加入第三项比较。
所有仿真日志在results；仅RTL功能和时钟活动通过不能宣称实际节能率。

## 来源

reference/保存任务38015538测量RTL的原样快照及单DUT测试激励。`build_sources.py`从这些快照重建共享运算部分；原项目不修改。
source_manifest.json记录源文件与生成代码hash。压缩包包含这些参考快照，支持移到服务器独立运行。
