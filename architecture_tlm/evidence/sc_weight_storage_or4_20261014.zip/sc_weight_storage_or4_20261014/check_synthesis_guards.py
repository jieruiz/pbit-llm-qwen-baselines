"""Elaboration checks only: a missing memory/ICG must never count as zero PPA."""
import argparse,json,pathlib,subprocess,os
ROOT=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--iverilog');p.add_argument('--ivl-base');a=p.parse_args()
iv=a.iverilog or str(ROOT/'tools/iverilog/bin/iverilog.exe')
base=a.ivl_base or str(ROOT/'tools/iverilog/lib/ivl')
sources=[str(x) for x in sorted((ROOT/'rtl').glob('*.sv'))]
rows=[]
for top,missing in [('sc_or4_weight_dff_baseline',None),('sc_or4_weight_gated_dff','sc_ws_tech_icg'),('sc_or4_weight_sram','sc_ws_tech_sram_parallel')]:
    cmd=[iv,'-B',base,'-g2012','-DSYNTHESIS','-s',top,'-o',str(ROOT/'results'/('guard_'+top+'.vvp'))]+sources
    r=subprocess.run(cmd,capture_output=True,text=True,cwd=ROOT)
    output=r.stdout+r.stderr
    (ROOT/'results'/('guard_'+top+'.log')).write_text(output)
    passed=(r.returncode==0) if missing is None else (r.returncode!=0 and missing in output)
    rows.append({'top':top,'check_passed':passed,'missing_binding':missing})
    if not passed:raise RuntimeError(top+' guard failed\n'+output)
(ROOT/'results/synthesis_guards.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS baseline elaborates; gated and SRAM require real bindings. No PPA executed.')
