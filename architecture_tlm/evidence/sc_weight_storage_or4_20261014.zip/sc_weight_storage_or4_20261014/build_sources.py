"""Reuse the archived measurement arithmetic; replace only weight storage."""
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'reference'
DEST = ROOT / 'rtl'

def emit(name, text):
    (DEST/name).write_text(text, encoding='utf-8')

core = (SOURCE/'sc_grouped_or_core.sv').read_text()
core = core.replace('module sc_grouped_or_core #(', 'module sc_ws_or_core #(')
core = core.replace('input wire clk, rst_n, cfg_we, start, sample_valid,',
                    'input wire clk, rst_n, cfg_any, start, sample_valid,')
core = core.replace('    input wire [ADDR_W-1:0] cfg_addr,\n    input wire signed [W-1:0] cfg_weight,',
                    '    input wire [N*(W+1)-1:0] weight_words,')
core = core.replace('    reg [W-1:0] weight_mag[0:N-1];\n    reg [N-1:0] weight_sign;',
                    '    wire [W-1:0] weight_mag[0:N-1];\n    wire [N-1:0] weight_sign;')
core = core.replace('start&&!busy&&!cfg_we', 'start&&!busy&&!cfg_any')
first = core.index('    genvar wi;')
last = core.index('    wire [N-1:0] negative=')
core = core[:first] + '''    genvar wi;
    generate for(wi=0;wi<N;wi=wi+1) begin:weight_decode
        assign weight_mag[wi]=weight_words[wi*(W+1)+:W];
        assign weight_sign[wi]=weight_words[wi*(W+1)+W];
    end endgenerate

''' + core[last:]
core = core.replace('sc_go_popcount', 'sc_ws_popcount').replace('sc_go_cached_accumulator', 'sc_ws_cached_accumulator').replace('sc_go_reset_mask', 'sc_ws_reset_mask')
emit('sc_ws_or_core.sv', core)
for name in ['sc_go_cached_accumulator.sv', 'sc_go_reset_mask.sv']:
    text = (SOURCE/name).read_text().replace('sc_go_cached_accumulator','sc_ws_cached_accumulator').replace('sc_go_reset_mask','sc_ws_reset_mask')
    emit(name.replace('sc_go_', 'sc_ws_'), text)

ports='''input wire clk,rst_n,cfg_weight_we,cfg_input_we,start,sample_valid,
    input wire [5:0] cfg_addr,input wire signed [7:0] cfg_weight,
    input wire [12:0] cfg_probability,input wire cfg_sign,
    input wire [767:0] random_words,output wire busy,done,update_main,
    output wire signed [26:0] raw_sum,output wire weight_clock'''
connections=''' .clk(clk),.rst_n(rst_n),.cfg_weight_we(cfg_weight_we),.cfg_input_we(cfg_input_we),
        .start(start),.sample_valid(sample_valid),.cfg_addr(cfg_addr),.cfg_weight(cfg_weight),
        .cfg_probability(cfg_probability),.cfg_sign(cfg_sign),.random_words(random_words),
        .busy(busy),.done(done),.update_main(update_main),.raw_sum(raw_sum),.weight_clock(weight_clock)'''
wrappers=['`timescale 1ns/1ps\n// N64 W8 P12 T4096 OR4 B1. Compile ONE top for PPA.\n']
for mode,name in enumerate(['sc_or4_weight_dff_baseline','sc_or4_weight_gated_dff','sc_or4_weight_sram']):
    wrappers.append(f'module {name}(\n    {ports}\n);\n'
                    f'    sc_ws_top #(.STORAGE({mode})) u_dut(\n{connections}\n    );\nendmodule\n')
emit('sc_ws_fixed_tops.sv','\n'.join(wrappers))

# Single-DUT activity harness. Reuse historical matched stimulus/scoreboard;
# configuration writes both interfaces here (reuse is tested separately).
tb=(SOURCE/'tb_power.sv').read_text()
tb=tb.replace('module tb_power;', 'module tb_weight_power;')
tb=tb.replace('parameter integer OR_GROUP=4,BATCH=4,LOG_T=12;',
              'parameter integer OR_GROUP=4,BATCH=1,LOG_T=12,STORAGE=1;')
split=tb.index('    wire ref_busy')
head=tb[:split].replace('.cfg_we(cfg_we)', '.cfg_weight_we(cfg_we),.cfg_input_we(cfg_we)')
head=head.replace('sc_grouped_or_top #(.OR_GROUP(OR_GROUP),.BATCH(BATCH),.LOG_T(LOG_T),.ACC_W(ACC_W))',
                  'sc_ws_top #(.OR_GROUP(OR_GROUP),.BATCH(BATCH),.LOG_T(LOG_T),.ACC_W(ACC_W),.STORAGE(STORAGE))')
tb=head+tb[split:].replace('ref_sc_grouped_or_top', 'sc_grouped_or_top')
tb=tb.replace('$isunknown({busy,done,update_main,raw_sum})', "((^{busy,done,update_main,raw_sum})===1'bx)")
(ROOT/'sim/tb_weight_power.sv').write_text(tb)

manifest = {'arithmetic_source':'reference/ (unchanged snapshot of task38015538 measurement RTL)', 'defaults':{'N':64,'W':8,'P_W':12,'LOG_T':12,'OR_GROUP':4,'BATCH':1},
            'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(list(DEST.glob('*.sv'))+list(SOURCE.glob('*.sv')))}}
(ROOT/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Generated shared OR4/popcount arithmetic from the archived measurement RTL')
